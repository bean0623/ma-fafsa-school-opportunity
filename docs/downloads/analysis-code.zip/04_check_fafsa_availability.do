/* MA SES project: FAFSA data availability and correlation-export repair.
   Run the whole file after 03. Stata 16+, no packages.
   No regressions are rerun. The 03 analysis-ready DTA is not overwritten.
   Only the correlation table's p-values are repaired in the existing 03 outputs.
*/
version 16.0
clear all
set more off
set varabbrev off
set linesize 160
global MA_PROJECT "/path/to/MA_SES_Project"
global MA03 "$MA_PROJECT/output/03_analysis"
global MA04 "$MA03/04_availability"
cd "$MA_PROJECT"
capture mkdir "$MA04"
capture log close _all
log using "$MA04/04_availability.log", text replace

* 1. Correct the custom Pearson p-value export using numeric variables.
use "$MA03/03_correlations.dta", clear
assert _N==120
isid x y
assert inrange(correlation,-1,1) if !missing(correlation)
clonevar p_before_repair=p
replace p=.
replace p=2*ttail(n-2,abs(correlation)*sqrt((n-2)/(1-correlation^2))) ///
    if n>2 & abs(correlation)<1 & !missing(correlation,n)
replace p=0 if n>2 & abs(correlation)==1 & !missing(correlation,n)
assert inrange(p,0,1) if !missing(p)
gen double p_abs_change=abs(p-p_before_repair)
gen byte negative_correlation=correlation<0 & !missing(correlation)
quietly count if negative_correlation==1
assert r(N)==39
display as text "Recomputed p-values for all 120 pairs, including 39 negative correlations."
quietly summarize p_abs_change
display as text "Largest absolute change from the previous export: " as result %10.8f r(max)
export delimited using "$MA04/04_correlation_repair_check.csv", replace
keep x y n correlation p
save "$MA03/03_correlations.dta", replace
gen str120 inference_note="Exploratory Pearson p; school independence assumed; not adjusted for district clustering or multiple tests"
export delimited using "$MA03/03_correlations.csv", replace

* 2. Use the SAME 407-school sample and SAME SES groups as 03.
use "$MA03/03_analysis_ready.dta", clear
assert _N==415
isid school_code
quietly count if ma_primary==1
assert r(N)==407
assert !missing(ma_ses3,grade12_enrollment) & grade12_enrollment>0 if ma_primary==1
gen byte ma04_usable=!missing(ma_fafsa)
assert ma04_usable==ma_fafsa_senior_usable
quietly count if ma_primary==1 & ma04_usable==1
assert r(N)==356
gen byte ma04_reason=0
replace ma04_reason=7 if ma_primary==0
replace ma04_reason=1 if ma_primary==1 & ma04_usable==1
replace ma04_reason=2 if ma_primary==1 & ma04_usable==0 & fafsa_suppressed==1
replace ma04_reason=3 if ma_primary==1 & ma04_usable==0 ///
    & fafsa_fed_code=="" & fafsa_review_flag==0
replace ma04_reason=4 if ma_primary==1 & ma04_usable==0 & fafsa_review_flag==1
replace ma04_reason=5 if ma_primary==1 & ma04_usable==0 & ma_fafsa_over100==1
replace ma04_reason=6 if ma_primary==1 & ma04_usable==0 & ma_fafsa_multirow==1
assert inrange(ma04_reason,1,7)
label define ma04_reason_label 1 "Usable screened estimate" 2 "Suppressed count (<5)" ///
    3 "No federal source match" 4 "Prior match rejected / review" ///
    5 "Completions exceed enrolled seniors" 6 "Multiple federal rows / campus coverage" ///
    7 "Outside positive-senior analysis sample"
label values ma04_reason ma04_reason_label
gen double ma04_seniors_covered=grade12_enrollment*ma04_usable if ma_primary==1
label var ma04_seniors_covered "Seniors enrolled in schools with a usable rate; not FAFSA completers"
tab ma_ses3 ma04_reason if ma_primary==1, missing

* 3. School-level availability and enrollment coverage, statewide and BPS.
foreach geo in Statewide BPS {
    preserve
    keep if ma_primary==1
    if "`geo'"=="BPS" keep if ma_bps==1
    collapse (count) n_schools=ma04_usable ///
        (sum) n_usable=ma04_usable seniors_total=grade12_enrollment ///
        seniors_in_usable_schools=ma04_seniors_covered, by(ma_ses3)
    if "`geo'"=="BPS" {
        quietly count if ma_ses3==3
        if r(N)==0 {
            local newN=_N+1
            set obs `newN'
            replace ma_ses3=3 in L
            foreach v in n_schools n_usable seniors_total seniors_in_usable_schools {
                replace `v'=0 in L
            }
        }
    }
    decode ma_ses3, gen(ses_label)
    gen long n_unavailable=n_schools-n_usable
    gen double school_available_pct=100*n_usable/n_schools
    gen double school_unavailable_pct=100*n_unavailable/n_schools
    gen double senior_school_coverage_pct=100*seniors_in_usable_schools/seniors_total
    label var senior_school_coverage_pct "Seniors enrolled at usable-rate schools (%); not individual matching/completion"
    gen str80 coverage_note=""
    replace coverage_note="No BPS schools in this statewide group; percentages undefined" if n_schools==0
    assert inrange(school_available_pct,0,100) if n_schools>0
    assert inrange(senior_school_coverage_pct,0,100) if seniors_total>0
    export delimited using "$MA04/04_availability_`geo'.csv", nolabel replace
    list ma_ses3 n_schools n_usable school_available_pct senior_school_coverage_pct, noobs
    if "`geo'"=="Statewide" {
        set scheme s2color
        graph bar (asis) school_available_pct, over(ma_ses3,label(labsize(small))) ///
            bar(1,color(navy)) yscale(range(0 100)) ylabel(0(20)100) ///
            ytitle("Schools with a usable estimated FAFSA rate (%)") ///
            title("FAFSA data availability across SES groups",size(medsmall)) ///
            note("Same 407-school sample and fixed statewide groups as the main analysis." ///
                 "Unavailable includes suppression, unmatched records and screened source issues.",size(vsmall)) ///
            graphregion(color(white)) name(ma04_availability,replace)
        graph export "$MA04/04_fafsa_availability.png", width(1800) replace
        graph export "$MA04/04_fafsa_availability.svg", replace
    }
    restore
}

* Reasons are mutually exclusive. Each SES group's reason counts sum to its size.
preserve
keep if ma_primary==1
collapse (count) n_schools=grade12_enrollment ///
    (sum) seniors=grade12_enrollment, by(ma_ses3 ma04_reason)
decode ma_ses3, gen(ses_label)
decode ma04_reason, gen(reason_label)
export delimited using "$MA04/04_missingness_reasons.csv", nolabel replace
restore
preserve
keep if ma_primary==1 & ma04_usable==0
assert _N==51
keep school_code school_name district_name school_type ma_ses3 ///
    sel_low_income_pct grade12_enrollment fafsa_complete_raw ///
    fafsa_match_method ma04_reason ma_source_review
decode ma04_reason, gen(reason_label)
export delimited using "$MA04/04_schools_without_usable_fafsa.csv", nolabel replace
restore

* 4. Compare size/composition of available versus unavailable schools.
preserve
keep if ma_primary==1
collapse (count) n_schools=grade12_enrollment ///
    (mean) mean_seniors=grade12_enrollment mean_low_income=sel_low_income_pct ///
    (median) median_seniors=grade12_enrollment, by(ma_ses3 ma04_usable)
export delimited using "$MA04/04_availability_school_size.csv", nolabel replace
restore

display as result "AVAILABILITY CHECK COMPLETED: correlation export repaired; coverage tables and chart saved."
display as text "Models were not rerun. The 03 analysis-ready DTA was not overwritten."
display as text "Availability means a usable school estimate, not proof of FAFSA completion or student-level coverage."
display as text "Send 04_availability.log and 04_availability_Statewide.csv for runtime review."
log close
