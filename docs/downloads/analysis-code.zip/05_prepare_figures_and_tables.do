/* MA SES project: presentation figures and tables, after checked steps 03/04.
   Stata 16+, built-in commands only. No models are estimated or changed.
   All new files are written to output/05_presentation; earlier outputs stay intact.
*/
version 16.0
clear all
set more off
set varabbrev off
set linesize 160
global MA_PROJECT "/path/to/MA_SES_Project"
global MA03 "$MA_PROJECT/output/03_analysis"
global MA04 "$MA03/04_availability"
global MA05 "$MA_PROJECT/output/05_presentation"
cd "$MA_PROJECT"
capture mkdir "$MA05"
capture mkdir "$MA05/figures"
capture log close _all
log using "$MA05/05_presentation.log", text replace
confirm file "$MA04/04_availability_Statewide.csv"
set scheme s2color

* 1. Use checked, saved group summaries. Do not recompute groups or fit models.
use "$MA03/03_group_descriptives.dta", clear
keep if grouping=="ma_ses3" & inlist(outcome,"ma_fafsa","college_attend_pct", ///
    "grad_pct","masscore_completed_pct","ap_perf_pct_score_3_5","att_chronic_abs_10pct")
assert _N==36
isid geography ses_group outcome
gen long n_missing=n_group-n_available
assert n_available+n_missing==n_group
assert inrange(mean,0,100) if !missing(mean)
gen byte outcome_order=.
replace outcome_order=1 if outcome=="ma_fafsa"
replace outcome_order=2 if outcome=="college_attend_pct"
replace outcome_order=3 if outcome=="grad_pct"
replace outcome_order=4 if outcome=="masscore_completed_pct"
replace outcome_order=5 if outcome=="ap_perf_pct_score_3_5"
replace outcome_order=6 if outcome=="att_chronic_abs_10pct"
gen str80 outcome_label=""
replace outcome_label="Estimated FAFSA completion rate" if outcome_order==1
replace outcome_label="College attendance among graduates" if outcome_order==2
replace outcome_label="Four-year graduation rate" if outcome_order==3
replace outcome_label="MassCore completion among graduates" if outcome_order==4
replace outcome_label="AP exams scoring 3-5" if outcome_order==5
replace outcome_label="Whole-school chronic absence" if outcome_order==6
gen str150 population_note=""
replace population_note="2025-26 aid cycle; through May 31, 2025; divided by 2024-25 enrolled seniors; screened estimate" if outcome_order==1
replace population_note="2024-25 graduates; college follow-up window remains unconfirmed" if outcome_order==2
replace population_note="2025 four-year graduation cohort" if outcome_order==3
replace population_note="2024-25 graduates" if outcome_order==4
replace population_note="2024-25 AP exams; exam performance, conditional on participation/reporting" if outcome_order==5
replace population_note="2024-25 students across all grades enrolled at each school" if outcome_order==6
gen str32 ses_label=""
replace ses_label="Higher low-income share" if ses_group==1
replace ses_label="Middle low-income share" if ses_group==2
replace ses_label="Lower low-income share" if ses_group==3
gen double school_available_pct=100*n_available/n_group if n_group>0
gen str100 comparison_note="Unweighted school means; fixed statewide low-income terciles; descriptive associations"
sort geography outcome_order ses_group
order geography outcome_order outcome outcome_label ses_group ses_label n_group ///
    n_available n_missing school_available_pct mean sd minimum maximum population_note
export delimited using "$MA05/05_outcomes_by_ses.csv", replace
save "$MA05/05_outcomes_by_ses.dta", replace

local outcomes ma_fafsa college_attend_pct grad_pct masscore_completed_pct ///
    ap_perf_pct_score_3_5 att_chronic_abs_10pct
foreach geo in Statewide BPS {
    foreach y of local outcomes {
        * All six outcomes are in the table; two BPS charts focus on FAFSA/college.
        if "`geo'"=="Statewide" | inlist("`y'","ma_fafsa","college_attend_pct") {
            preserve
            keep if geography=="`geo'" & outcome=="`y'"
            assert _N==3
            sort ses_group
            local n1=n_available[1]
            local n2=n_available[2]
            local n3=n_available[3]
            local charttitle=outcome_label[1]
            local period=population_note[1]
            local source "Source: Massachusetts DESE; reporting populations differ across outcomes."
            if "`y'"=="ma_fafsa" local source "Sources: U.S. ED/FSA historical May 2026 release and Massachusetts DESE enrollment."
            local caveat "Current merged sample; N is schools with a usable outcome; missing values excluded."
            if "`geo'"=="BPS" local caveat "No BPS schools in lower-share group; middle group has 3 exam schools and Boston Arts Academy."
            label define ma05_group 1 "Higher share (N=`n1')" ///
                2 "Middle share (N=`n2')" 3 "Lower share (N=`n3')", replace
            label values ses_group ma05_group
            graph bar (asis) mean if n_group>0, over(ses_group,label(labsize(small))) ///
                bar(1,color(navy)) blabel(bar,format(%4.1f) position(inside) color(white) size(medsmall)) ///
                yscale(range(0 100)) ylabel(0(20)100,angle(horizontal)) ///
                ytitle("Mean school rate (%)") title("`geo': `charttitle'",size(medsmall)) ///
                subtitle("Groups defined by student low-income share",size(small)) ///
                note("Unweighted school means. `period'." "`caveat'" "`source'",size(vsmall)) ///
                graphregion(color(white)) name(ma05_means,replace)
            graph export "$MA05/figures/05_`geo'_`y'_ses3.png", width(1800) replace
            graph export "$MA05/figures/05_`geo'_`y'_ses3.svg", replace
            restore
        }
    }
}

* 2. Availability is a separate outcome: it is not FAFSA completion.
import delimited using "$MA04/04_availability_Statewide.csv", clear varnames(1) asdouble
assert _N==3
isid ma_ses3
assert n_schools==n_usable+n_unavailable
assert abs(school_available_pct-100*n_usable/n_schools)<1e-10
assert abs(senior_school_coverage_pct-100*seniors_in_usable_schools/seniors_total)<1e-10
sort ma_ses3
forvalues g=1/3 {
    local u`g'=n_usable[`g']
    local t`g'=n_schools[`g']
}
label define ma05_coverage 1 "Higher share (`u1'/`t1')" ///
    2 "Middle share (`u2'/`t2')" 3 "Lower share (`u3'/`t3')", replace
label values ma_ses3 ma05_coverage
export delimited using "$MA05/05_fafsa_coverage.csv", nolabel replace
graph bar (asis) school_available_pct, over(ma_ses3,label(labsize(small))) ///
    bar(1,color(navy)) blabel(bar,format(%4.1f) position(inside) color(white) size(medsmall)) ///
    yscale(range(0 100)) ylabel(0(20)100,angle(horizontal)) ///
    ytitle("Schools with usable estimates (%)") title("FAFSA data availability",size(medsmall)) ///
    subtitle("Fixed statewide low-income groups; usable / eligible school counts",size(small)) ///
    note("407 eligible schools in the current merged sample; 356 usable estimated rates." ///
         "Unavailable includes suppression, unmatched records and screened source issues; it does not mean zero completion.",size(vsmall)) ///
    graphregion(color(white)) name(ma05_coverage,replace)
graph export "$MA05/figures/05_fafsa_availability.png", width(1800) replace
graph export "$MA05/figures/05_fafsa_availability.svg", replace

* 3. Scatterplot: count the actual schools with both plotted coordinates.
use "$MA03/03_analysis_ready.dta", clear
assert _N==415
isid school_code
quietly count if ma_primary==1 & !missing(ma_fafsa,sel_low_income_pct)
assert r(N)==356
quietly count if ma_primary==1 & ma_bps==1 & !missing(ma_fafsa,sel_low_income_pct)
local nbps=r(N)
assert `nbps'==27
quietly count if ma_primary==1 & ma_bps==0 & !missing(ma_fafsa,sel_low_income_pct)
local nother=r(N)
assert `nother'==329
twoway (scatter ma_fafsa sel_low_income_pct if ma_primary==1 & ma_bps==0, ///
    mcolor(gs11) msymbol(oh) msize(small)) ///
    (scatter ma_fafsa sel_low_income_pct if ma_primary==1 & ma_bps==1, ///
    mcolor(navy) msymbol(O) msize(small)), ///
    legend(order(1 "Other districts (N=`nother')" 2 "BPS (N=`nbps')") size(small)) ///
    xscale(range(0 100)) yscale(range(0 100)) ///
    xlabel(0(20)100) ylabel(0(20)100,angle(horizontal)) ///
    xtitle("Students identified as low income (%)") ytitle("Estimated FAFSA rate (%)") ///
    title("Boston Public Schools in the statewide comparison",size(medsmall)) ///
    note("FAFSA completions through May 31, 2025 for 2025-26 aid / 2024-25 enrolled seniors; screened estimates." ///
         "Sources: U.S. ED/FSA historical May 2026 release and Massachusetts DESE. School-level associations.",size(vsmall)) ///
    graphregion(color(white)) name(ma05_scatter,replace)
graph export "$MA05/figures/05_boston_fafsa_scatter.png", width(1800) replace
graph export "$MA05/figures/05_boston_fafsa_scatter.svg", replace

* 4. Display already-checked adjusted coefficients and district-clustered CIs.
import delimited using "$MA03/03_main_low_income_results.csv", clear varnames(1) asdouble
assert _N==6
isid outcome
assert term=="ma_low10" & vce=="district clustered"
assert ci_low<=b & b<=ci_high
assert inrange(p,0,1) & inrange(p_holm,0,1)
gen byte outcome_order=.
replace outcome_order=1 if outcome=="ma_fafsa"
replace outcome_order=2 if outcome=="college_attend_pct"
replace outcome_order=3 if outcome=="grad_pct"
replace outcome_order=4 if outcome=="masscore_completed_pct"
replace outcome_order=5 if outcome=="ap_perf_pct_score_3_5"
replace outcome_order=6 if outcome=="att_chronic_abs_10pct"
assert inrange(outcome_order,1,6)
sort outcome_order
forvalues g=1/6 {
    local nn`g'=n[`g']
}
label define ma05_outcome 1 "Estimated FAFSA (N=`nn1')" 2 "College attendance (N=`nn2')" ///
    3 "Four-year graduation (N=`nn3')" 4 "MassCore (N=`nn4')" ///
    5 "AP exams scoring 3-5 (N=`nn5')" 6 "Chronic absence (N=`nn6')", replace
label values outcome_order ma05_outcome
decode outcome_order, gen(outcome_label)
gen str100 effect_unit="Percentage-point difference per 10 percentage points higher student low-income share"
gen str150 inference_note="Adjusted school-level associations; district-clustered 95% CIs are not multiplicity-adjusted; six-test Holm p is in p_holm"
export delimited using "$MA05/05_adjusted_associations.csv", nolabel replace
twoway (rcap ci_low ci_high outcome_order, horizontal lcolor(navy)) ///
    (scatter outcome_order b, mcolor(navy) msymbol(O)), ///
    yscale(reverse) ylabel(1/6,valuelabel angle(horizontal) labsize(small)) ///
    ytitle("") xtitle("Percentage-point difference per 10 pp higher low-income share",size(small)) ///
    xline(0,lcolor(gs8) lpattern(dash)) legend(off) ///
    title("Adjusted school-level associations",size(medsmall)) ///
    note("Dots: adjusted associations. Lines: district-clustered 95% CIs." ///
         "CIs precede multiple-test adjustment; Holm p-values are in the results table." ///
         "Controls: school size/type, English-learner share, and disability share." ///
         "Outcome populations differ. These are associations, not causal effects.",size(vsmall)) ///
    graphregion(color(white)) name(ma05_coefficients,replace)
graph export "$MA05/figures/05_adjusted_associations.png", width(1800) replace
graph export "$MA05/figures/05_adjusted_associations.svg", replace

display as result "PRESENTATION FILES COMPLETED: 11 charts and 3 CSV tables saved."
display as text "No models were rerun. Earlier datasets, results and figures were not overwritten."
display as text "Send 05_presentation.log and the statewide FAFSA, BPS FAFSA, availability and adjusted-associations PNGs."
log close
